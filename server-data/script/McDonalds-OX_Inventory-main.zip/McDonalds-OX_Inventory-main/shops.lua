	McDonalds = {
		name = 'McDonalds',
		inventory = {
			{ name = 'bigmac', price = 50, currency = 'money' },--
			{ name = 'mcchicken', price = 50, currency = 'money' },--
			{ name = 'quarterpounder', price = 50, currency = 'money' },
			{ name = 'dquarterpounder', price = 50, currency = 'money' },--
			{ name = 'filet-o-fish', price = 50, currency = 'money' },--
			{ name = 'cheeseburger', price = 50, currency = 'money' },--
			{ name = 'bigmac_meal', price = 150, currency = 'money' },--
			{ name = 'mcchicken_meal', price = 150, currency = 'money' },
			{ name = 'quarterpounder_meal', price = 150, currency = 'money' },
			{ name = 'dquarterpounder_meal', price = 150, currency = 'money' },
			{ name = 'filet-o-fish_meal', price = 150, currency = 'money' },
			{ name = 'cheeseburger_meal', price = 150, currency = 'money' },
			{ name = 'dcheeseburger', price = 50, currency = 'money' },
			{ name = 'tcheeseburger', price = 50, currency = 'money' },
			{ name = '6pnuggets', price = 50, currency = 'money' },
			{ name = '10pnuggets', price = 50, currency = 'money' },
			{ name = '20pnuggets', price = 50, currency = 'money' },
			{ name = 'dcheeseburger_meal', price = 150, currency = 'money' },
			{ name = 'tcheeseburger_meal', price = 150, currency = 'money' },
			{ name = '6pnuggets_meal', price = 70, currency = 'money' },
			{ name = '10pnuggets_meal', price = 100, currency = 'money' },
			{ name = '20pnuggets_meal', price = 150, currency = 'money' },
			{ name = 'sfries', price = 50, currency = 'money' },
			{ name = 'mfries', price = 70, currency = 'money' },
			{ name = 'lfries', price = 100, currency = 'money' },
			{ name = 'hotapplepie', price = 50, currency = 'money' },
			{ name = 'ssconef', price = 50, currency = 'money' },
			{ name = 'sscone', price = 50, currency = 'money' },
			{ name = 'mflurryo', price = 50, currency = 'money' },
			{ name = 'mflurrym', price = 50, currency = 'money' },
			{ name = 'cocacola', price = 100, currency = 'money' },
		}, locations = {
			vec3(88.7901, 286.1420, 110.2077),
		}, targets = {
			{ loc = vec3(88.7901, 286.1420, 110.2077), length = 3.0, width = 1.5, heading = 240.00, minZ = 105.00, maxZ = 115.00, distance = 2.0 },
		}
	},
