# McDonalds-ESX-OX_Inventory

Michy#4320 on discord :)

Blackout Developments Discord (https://discord.gg/hhgFKbERqk)

Michy_TV Twitch https://www.twitch.tv/michy_tv

Fourm Post 
https://forum.cfx.re/t/mcdonalds-items-ox-inventory/5070731


McDonalds add-on for those wanting to add food and items for esx and ox_inventory

To install ive made it easy to copy and paste them into your server, just add them into the paths listed.


Support the artist

Alot of time went into making the images for the items to make them all look the same, Please if you feel that the 
art work and time taken to make this is something you appreiate you can dontate to my Ko-Fi here, https://ko-fi.com/michytv
