Continuing the discussion from [[Release] Realistic Vehicle Failure](https://forum.cfx.re/t/release-realistic-vehicle-failure/57801):

# RealisticVehicleFailure FIXED 2023
I for one loved and missed the RealisticVehicleFailure with the ability to type `/repair` and it sort of give you a little fix to hold you off until you got to a mechanic. Well with the latest release that no longer exists / works. Well, it does now in my version! There was no license in the file and the original repo on Github was deleted. So here is a WORKING copy WITH the `/repair` command working with configurable auto shops in the config file.

I spent the last 2 hours looking for a working copy of this script, and I finally decided to just fix the broken one. Seeing that the original post was closed, here is this thread continuing it.

Please note, I dont consider myself to be a FiveM script developer by any means and I don't plan to maintain or support this script directly. Please reference the previous article for documentation and more. I did go ahead and switch it to use an `fxmanifest.lua` file as-well. Figured it was time for that to be updated.

I hope you guys enjoy!

**FiveM Resource Link:** https://forum.cfx.re/t/realisticvehiclefailure-fixed-2023/5074189

**P.S.** [Attempted Fix](https://forum.cfx.re/t/realistic-vehicle-failure-repair-fix/4887760) this release was made in the past, however I was unable to get it to work for me, and DIY fixing your car is not suitable for my server. This fix brings back the ORIGINAL `/repair` that was meant to be used with proximity to mechanics!
