fx_version 'adamant'

games {
	'gta5'
}

author 'iEns, Hyperz#0001'
version '2.0.0'
description 'A fixed version of iEns RealisticVehcileFailure script. Now with a working /repair command!'

client_scripts {
	"config.lua",
	"client.lua"
}

server_scripts {
	"config.lua",
	"server.lua"
}