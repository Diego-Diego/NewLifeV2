fx_version "cerulean"
games { 'gta5' }
lua54 'yes'
author 'Alcaline'
description 'Alca Eat Fork'
version '1.0.0'

data_file 'DLC_ITYP_REQUEST' 'stream/alca_anim_eat.ytyp'

escrow_ignore { 
    'stream/*.ydr',
    'stream/*.ytyp',
    'stream/*.ycd',
}

dependency '/assetpacks'