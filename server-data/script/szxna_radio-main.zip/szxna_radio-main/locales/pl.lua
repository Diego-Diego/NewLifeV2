Locales['pl'] = {
    ['menu_title'] = 'Radio',
    ['menu_frequency'] = 'Częstotliwość',
    ['menu_volume'] = 'Głośność',
    ['menu_disconnect_channel'] = 'Opuść kanał',
    ['menu_dialog_volume'] = 'Ustaw głośność',
    ['menu_dialog_frequency'] = 'Ustaw częstotliwość',
    ['controls_toggle_radio'] = 'Uruchom radio'
}
