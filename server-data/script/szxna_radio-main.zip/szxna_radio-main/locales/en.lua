Locales['en'] = {
    ['menu_title'] = 'Radio',
    ['menu_frequency'] = 'Freq.',
    ['menu_volume'] = 'Vol.',
    ['menu_disconnect_channel'] = 'Disconnect channel',
    ['menu_dialog_volume'] = 'Set the volume',
    ['menu_dialog_frequency'] = 'Set the frequency',
    ['controls_toggle_radio'] = 'Toggle Radio'
}
