<p align="center"><img src="https://cdn.discordapp.com/attachments/806845910474686467/1091751351391899759/radio_png.png"/><br>

# Information
- uses ox_lib (context menu), ESX and pma-voice
- you can change the volume
- blocks channels for selected jobs
- compatible with newest ox_inventory and esx-legacy
- tested on ESX 1.9.3
- preview: https://streamable.com/gjkcar
	
# Features

- Advanced configuration
- Compatible with the latest esx & ox
- Translation into different languages
- Blocks channels for selected jobs

# Instructions
- Download repo from github
- Configure in config.lua
- Add to server.cfg `start szxna_radio`

## Requirements

- es_extended
- ox_lib
- pma-voice
