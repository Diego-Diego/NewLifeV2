<div id="top"></div>

<br />
<div align="center">
  <a href="https://uniq.tebex.io">
    <img src="https://i.imgur.com/tsFkqzD.png" alt="Death Screen">
  </a>

  <h3 align="center">Death Screen</h3>

  <p align="center">
    <a href="https://discord.gg/WRknrjMZAS">Join Our Discord</a>
    ·
    <a href="https://uniq.tebex.io">Purchase Our Resources</a>
  </p>
</div>

## About This Resource

<a href="https://i.imgur.com/DsEorEI.png">Preview Resource</a>

* Clean and responsive UI
* Easy to configure & use
* ESX & QBCore compactibility
* Death Timer
* Killer (death reason)
* Emergency & accept to die buttons
* Choose between RP/Steam name

> Check out our [Documentation](https://uniq-team.gitbook.io/documentation/free-resources/death-screen) and find out how to set it up properly.

### **DISCLAIMER**
> If any bugs or problems are found, please report the problem/pull request on GitHub page.
