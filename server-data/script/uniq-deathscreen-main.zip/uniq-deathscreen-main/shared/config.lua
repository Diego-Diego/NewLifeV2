Config = {}

Config.Debug = true
Config.VersionChecking = true
Config.Framework = 'esx' -- esx, qbcore
Config.UseRPName = true
Config.Timer = 300 -- in seconds
Config.PriceForDead = 1000
Config.NetworkProblem = true
Config.RespawnCoords = {
    coords = {
        x = 298.7508,
        y = -1440.6846,
        z = 29.7929
    },
    heading = 44.1302,
}

Config.Translation = {
    Suicide = "Suicide",
    Unknown = "Unknown",
    MoneyRemoved = "You have been removed $%s for accepting to die early"
}
