# WeaponAnimationMenuV2
You can set the command and weapons you want to use in the config. Once started players options will be saved client side.

# Need Support?

[![Need Support?](https://i.imgur.com/fqKYWeV.png)](https://discord.gg/Z9Mxu72zZ6)

# How to install:
Drag WeaponAnimationMenu to your resources folder and write start WeapnAnimationMenuV2 in your server cfg.

# Disclaimer
DO NOT change the name of the resource or it will break and you will look stupid.

# Video Preview
https://youtu.be/YrvB3PaD9dI
