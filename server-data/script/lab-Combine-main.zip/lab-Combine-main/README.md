# lab-Combine
Combine items feature for ox_inventory

Browse server.lua to configure your combinations.
Follow the commented example, its quite simple.

Depedencies:
-ox_inventory
-ox_lib

Preview:
https://streamable.com/slmnj1
