# Blip-Icon-Stream

Hello all
I was working on this to have more stylized blips for my server and thought I would share it here. All of the icons are from the [Icons8 website](https://icons8.com/icon/set/popular/sf-regular) and the ones I used are in the *icons* folder. 

The stylized blips are on the second texture file of the TYD, so the range starts at 512 on the [blips list](https://docs.fivem.net/docs/game-references/blips/)

![_blips_texturesheet_ng](https://user-images.githubusercontent.com/116332087/227812562-04fa75d9-d5b8-48f6-bc31-64f9a5584737.png)
