fx_version 'cerulean'
game 'gta5'
version '1.1.5'
lua54 'yes'

-- this is here cause its needed apparently
-- get milk from store