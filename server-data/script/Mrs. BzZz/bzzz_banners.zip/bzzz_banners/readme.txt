Hi,
thank you for your purchase.


--------------------------------------------------

My contact: 
Cfx forum:			 https://forum.cfx.re/u/bzzzi/summary
Tebex:				 https://bzzz.tebex.io/
Discord:			 https://discord.gg/PpAHBCMW97
--------------------------------------------------



Installation:
1) Insert folder "bzzz_banners" to resources folder
2) Add to server.cfg
3) Restart server




--------------------------------------------------
If you stream props in another resource, you must edit the fxmanifest.
Add this line:
data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_prop_electro_banners.ytyp'

Then the server must be restarted. 
YTYP loads properties of props.
--------------------------------------------------

You can change the textures in OpenIV.
I recommend using 256 x 512 textures.