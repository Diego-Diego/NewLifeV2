fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Bzzz - Banners'
version '1.1.0'



data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_prop_electro_banners.ytyp'


