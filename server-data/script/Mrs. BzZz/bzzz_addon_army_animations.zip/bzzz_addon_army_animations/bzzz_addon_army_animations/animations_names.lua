--you can copy and paste this code to the dpemotes

["army1"] = {"bzzz@animation@army1", "bz_army1", "Army 1", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},
   ["army1l"] = {"bzzz@animation@army1_left", "bz_army1_left", "Army 1 Left", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},
   ["army1p"] = {"bzzz@animation@army1_right", "bz_army1_right", "Army 1 Right", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},
   ["army2"] = {"bzzz@animation@army2", "bz_army2", "Army 2", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},
   ["army2l"] = {"bzzz@animation@army2_left", "bz_army2_left", "Army 2 Left", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},
   ["army2p"] = {"bzzz@animation@army2_right", "bz_army2_right", "Army 2 Right", AnimationOptions =
   {
       EmoteLoop = true,
       EmoteMoving = false,
   }},