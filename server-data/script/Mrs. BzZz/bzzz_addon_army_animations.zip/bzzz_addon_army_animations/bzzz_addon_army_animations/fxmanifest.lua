fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Army animations'
version '1.0.0'


