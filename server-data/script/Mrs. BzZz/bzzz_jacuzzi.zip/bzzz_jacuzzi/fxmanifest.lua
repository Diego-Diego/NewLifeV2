fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Bzzz Jacuzzi - free MLO'
version '1.0.0'




