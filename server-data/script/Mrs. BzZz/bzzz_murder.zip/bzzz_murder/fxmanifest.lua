fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Murder animations'



data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_murderpack.ytyp'




