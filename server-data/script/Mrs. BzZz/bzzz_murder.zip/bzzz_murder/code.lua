-- 1) put YDR and YTYP files in any stream folder

-- 2) insert the path to the YTYP into fxmanifest
-- data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_murderpack.ytyp'

-- 3) copy and paste the code into dpemotes/client/animations.lua or edit for your script
-- commands: /e murder1, /e murder2, /e murder3, /e murder4
-------------------------------------------------------------------

-- Do you need help? Contact me

-------------------------------------------------------------------



["murder1"] = {"dead", "dead_e", "Murder Axe", AnimationOptions =
   {
    Prop = "bzzz_murder_axe001",
    PropBone = 18905,
    PropPlacement = {-0.22, 0.34, -0.3, -56.0, 98.0, 34.0},
    SecondProp = 'p_bloodsplat_s',
    SecondPropBone = 57005,
    SecondPropPlacement = {0.28, 0.17, -0.12, -98.0, -51.0, 237.0},
    EmoteLoop = true,
    EmoteMoving = false,
   }},

["murder2"] = {"dead", "dead_a", "Murder Pistol", AnimationOptions =
   {
    Prop = "w_pi_heavypistol",
    PropBone = 18905,
    PropPlacement = {0.27, 0.35, 0.05, -98.0, 2.0, 183.0},
    SecondProp = 'p_bloodsplat_s',
    SecondPropBone = 57005,
    SecondPropPlacement = {-0.8, 0.41, 0.0, -98.0, -7.0, 237.0},
    EmoteLoop = true,
    EmoteMoving = false,
   }},

["murder3"] = {"dead", "dead_b", "Murder Machete", AnimationOptions =
    {
    Prop = "bzzz_murder_machete001",
    PropBone = 18905,
    PropPlacement = {-0.22, 0.18, -0.67, 196.0, 157.0, -35.0},
    SecondProp = 'p_bloodsplat_s',
    SecondPropBone = 57005,
    SecondPropPlacement = {-0.28, -0.15, 0.00, 266.2, 182.3, -10.0},
    EmoteLoop = true,
    EmoteMoving = false,
   }},

["murder4"] = {"dead", "dead_a", "Murder Sex", AnimationOptions =
   {
    Prop = "prop_knife",
    PropBone = 12844,
    PropPlacement = {0.0, 0.07, 0.16, 170.0, 219.0, -67.0},
    SecondProp = 'bzzz_murder_durex001',
    SecondPropBone = 57005,
    SecondPropPlacement = {0.33, 1.13, -0.07, 263.0, 264.0, -85.0},
    EmoteLoop = true,
    EmoteMoving = false,
   }},