!!!!! add clothes to your addon pack !!!!!

The game has a limited amount for YMT files!!!
If you exceed the limits, the game will crash!


More information: https://github.com/DurtyFree/durty-cloth-tool/wiki/YMT-game-limit-and-crash-issues