fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Bzzz - Cloth - Swimwear'
version '1.1.0'

files {
  'mp_m_freemode_01_mp_m_bzzz_swimwear.meta',
  'mp_f_freemode_01_mp_f_bzzz_swimwear.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_bzzz_swimwear.meta'
data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_bzzz_swimwear.meta'