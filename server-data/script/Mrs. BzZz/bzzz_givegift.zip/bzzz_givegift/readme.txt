Hi,
thank you for your purchase.


--------------------------------------------------
My contact: 
Cfx forum:			 https://forum.cfx.re/u/bzzzi/summary
Tebex:				 https://bzzz.tebex.io/
Discord:			 https://discord.gg/PpAHBCMW97
--------------------------------------------------



Installation:
1) Insert folder "bzzz_givegift" to resources folder
2) Add to server.cfg
3) Restart server



If you stream props in another resource, you must edit the fxmanifest.
Add this line:
data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_prop_give_gift.ytyp'



Then the server must be restarted. 
YTYP loads properties of props.

--------------------------------------------------
This is the second version. Delete the old files.
Old file names:

bz_prop_jewel.ytyp
bz_prop_milka.ytyp
bz_prop_gift.ytyp
bz_prop_gift2.ytyp

bz_prop_jewel.ydr
bz_prop_milka.ydr
bz_prop_gift.ydr
bz_prop_gift2.ydr

bz@give_love@anim.ycd

--------------------------------------------------
DEV Logs:
- some textures have been edited
- some props have been optimized
- collisions are no longer static
- the Milka logo has been removed
- the coordinates of the props have been centered (it is necessary to change the coords in the animation)