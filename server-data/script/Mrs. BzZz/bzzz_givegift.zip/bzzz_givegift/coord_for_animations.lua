   ["gift"] = {"bz@give_love@anim", "bz_give", "Purple gift", AnimationOptions =
   {
       Prop = "bzzz_prop_gift_purple",
       PropBone = 57005,
	   PropPlacement = {0.15, -0.03, -0.14, -77.0, -120.0, 40.0},
       EmoteLoop = true,
       EmoteMoving = true,
   }},	
   
   ["gift2"] = {"bz@give_love@anim", "bz_give", "Orange gift", AnimationOptions =
   {
       Prop = "bzzz_prop_gift_orange",
       PropBone = 57005,
	   PropPlacement = {0.15, -0.03, -0.14, -77.0, -120.0, 40.0},
       EmoteLoop = true,
       EmoteMoving = true,
   }},
   
   ["jewel"] = {"bz@give_love@anim", "bz_give", "Jewel gift", AnimationOptions =
   {
       Prop = "bzzz_prop_gift_jewel",
       PropBone = 57005,
	   PropPlacement = {0.12, 0.0, -0.19, -41.0, -120.0, 40.0},
       EmoteLoop = true,
       EmoteMoving = true,
   }},
   
   ["bonbonier"] = {"bz@give_love@anim", "bz_give", "Bonbonier gift", AnimationOptions =
   {
       Prop = "bzzz_prop_gift_bonbonier",
       PropBone = 57005,
	   PropPlacement = {0.12, 0.0, -0.19, -41.0, -120.0, 40.0},
       EmoteLoop = true,
       EmoteMoving = true,
   }},